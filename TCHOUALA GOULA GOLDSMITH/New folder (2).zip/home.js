const button = document.getElementById("toggle-table");
    const table = document.getElementById("worker-table");

    button.addEventListener("click", () => {
      if (table.style.display === "none") {
        table.style.display = "table";
      } else {
        table.style.display = "none";
      }
    });